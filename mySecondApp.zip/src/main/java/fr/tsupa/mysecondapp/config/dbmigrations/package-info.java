/**
 * MongoDB database migrations using MongoBee.
 */
package fr.tsupa.mysecondapp.config.dbmigrations;
