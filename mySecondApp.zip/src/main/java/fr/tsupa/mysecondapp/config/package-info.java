/**
 * Spring Framework configuration files.
 */
package fr.tsupa.mysecondapp.config;
