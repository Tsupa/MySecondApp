/**
 * View Models used by Spring MVC REST controllers.
 */
package fr.tsupa.mysecondapp.web.rest.vm;
