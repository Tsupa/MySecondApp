/**
 * Spring Data JPA repositories.
 */
package fr.tsupa.mysecondapp.repository;
