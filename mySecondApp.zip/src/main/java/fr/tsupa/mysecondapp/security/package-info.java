/**
 * Spring Security configuration.
 */
package fr.tsupa.mysecondapp.security;
