/**
 * Service layer beans.
 */
package fr.tsupa.mysecondapp.service;
