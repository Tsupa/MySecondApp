/**
 * Data Transfer Objects.
 */
package fr.tsupa.mysecondapp.service.dto;
