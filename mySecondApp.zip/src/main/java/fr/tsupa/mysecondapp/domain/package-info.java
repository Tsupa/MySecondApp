/**
 * JPA domain objects.
 */
package fr.tsupa.mysecondapp.domain;
